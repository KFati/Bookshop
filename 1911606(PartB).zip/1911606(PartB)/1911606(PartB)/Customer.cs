﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class Customer : Form
    {
        public static List<clsCustomer> myCustomer;
        public Customer()
        {
            InitializeComponent();
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            txtId.Focus();
            myCustomer = new List<clsCustomer>() {
            new clsCustomer() { CustomerId = "1", CustomerName = "John Smith", Gender = "Male", PhoneNum = 58973546 },
            new clsCustomer() { CustomerId = "2", CustomerName = "Katherine Jones", Gender = "Female", PhoneNum = 57683543 },
            new clsCustomer() { CustomerId = "3", CustomerName = "Katie Jhonson", Gender = "Female", PhoneNum = 57891423 },
            new clsCustomer() { CustomerId = "4", CustomerName = "Paula Smith", Gender = "Female", PhoneNum = 57864532 },
            new clsCustomer() { CustomerId = "5", CustomerName = "Damon Salvatore", Gender = "Male", PhoneNum = 59083421 },
            new clsCustomer() { CustomerId = "6", CustomerName = "Matt Donovan", Gender = "Male", PhoneNum = 57613456 },
            new clsCustomer() { CustomerId = "7", CustomerName = "Tyler Brown", Gender = "Male", PhoneNum = 56753452 },
            new clsCustomer() { CustomerId = "8", CustomerName = "Caroline Forbes", Gender = "Female", PhoneNum = 56894725 },
            new clsCustomer() { CustomerId = "9", CustomerName = "Bonnie Bennet", Gender = "Female", PhoneNum = 56875342 },
            new clsCustomer() { CustomerId = "10", CustomerName = "Elena Gilbert", Gender = "Female", PhoneNum = 57863523 }
            };

            foreach (clsCustomer cust in myCustomer)
            {
                dataGridViewCustomers.Rows.Add(cust.CustomerId, cust.CustomerName, cust.Gender, cust.PhoneNum);
            }
        }

        

        private void dataGridViewCustomers_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                int selectedIndex = dataGridViewCustomers.CurrentCell.RowIndex;

                txtId.Text = dataGridViewCustomers.Rows[selectedIndex].Cells[0].Value.ToString();
                txtName.Text = dataGridViewCustomers.Rows[selectedIndex].Cells[1].Value.ToString();

                string gender = dataGridViewCustomers.Rows[selectedIndex].Cells[2].Value.ToString();

                if (gender.Equals("Male"))
                    radMale.Select();
                else
                    radFemale.Select();

                txtNum.Text = dataGridViewCustomers.Rows[selectedIndex].Cells[3].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show("Error!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }

        private void ClearTextBoxes()
        {
            txtName.Clear();
            txtId.Clear();
            txtNum.Clear();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                clsCustomer myCust = new clsCustomer();

                myCust.CustomerId = txtId.Text;
                myCust.CustomerName = txtName.Text;


                if (radMale.Checked)
                    myCust.Gender = "Male";
                else
                    myCust.Gender = "Female";

                myCust.PhoneNum = int.Parse(txtNum.Text);


                myCustomer.Add(myCust);
                dataGridViewCustomers.Rows.Add(myCust.CustomerId, myCust.CustomerName, myCust.Gender, myCust.PhoneNum);

                MessageBox.Show("Record added successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);


                ClearTextBoxes(); //Clears txtboxes once records are added
                txtId.Focus(); //Reverts to the ID textbox once records are added

            }
            catch 
            {
                MessageBox.Show("Please fill in all the information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult Result = MessageBox.Show("Are you sure you want to update record ?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (Result == DialogResult.Yes)
                {
                    int Index = dataGridViewCustomers.CurrentCell.RowIndex;
                    if (Index != -1)
                    {
                        dataGridViewCustomers.SelectedRows[0].Cells[0].Value = txtId.Text;
                        dataGridViewCustomers.SelectedRows[0].Cells[1].Value = txtName.Text;

                        string gender = string.Empty;

                        if (radMale.Checked)
                            gender = "Male";
                        else
                            gender = "Female";

                        dataGridViewCustomers.SelectedRows[0].Cells[2].Value = gender;
                        dataGridViewCustomers.SelectedRows[0].Cells[3].Value = txtNum.Text;
                        ClearTextBoxes();
                        MessageBox.Show("Record updated successfully", "Successful update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show("Error!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult Result = MessageBox.Show("Are you sure you want to delete record ?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (Result == DialogResult.Yes)
                {
                    int Index = dataGridViewCustomers.CurrentCell.RowIndex;
                    if (Index != -1)
                    {
                        dataGridViewCustomers.Rows.RemoveAt(Index);
                        ClearTextBoxes();
                    }
                    MessageBox.Show("Record deleted successfully", "Successful deletion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show("Error!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            clsPayment clsPayment = new clsPayment();
            clsPayment.customerId = txtId.Text;
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Press save to save the selected data for use in other forms");
        }
    }
}
