﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }
        string gender = "";
        private void Employee_Load(object sender, EventArgs e)
        {
            txtEmpId.Focus();
            listViewEmployees.CheckBoxes = true;
            listViewEmployees.FullRowSelect = true;
        }

        private void radMale_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void radFemale_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void ResetRecords()
        {
            txtEmpId.Clear();
            txtEmpName.Clear();
            txtEmpNum.Clear();
            txtPosition.Clear();

        }

        private void listViewEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (listViewEmployees.SelectedItems.Count > 0)
                {
                    ListViewItem item = listViewEmployees.SelectedItems[0];
                    txtEmpId.Text = item.SubItems[0].Text;
                    txtEmpName.Text = item.SubItems[1].Text;
                    gender = item.SubItems[2].Text;
                    txtEmpNum.Text = item.SubItems[3].Text;
                    txtPosition.Text = item.SubItems[4].Text;
                }
                else
                {
                    txtEmpId.Text = string.Empty;
                    txtEmpName.Text = string.Empty;
                    gender = string.Empty;
                    txtEmpNum.Text = string.Empty;
                    txtPosition.Text = string.Empty;
                }

                if (gender.Equals("Male"))
                {
                    radMale.Checked = true;
                }
                else if (gender.Equals("Female"))
                {
                    radFemale.Checked = true;
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                ListViewItem lviEmployeeRecords = new ListViewItem(txtEmpId.Text);
                lviEmployeeRecords.SubItems.Add(txtEmpName.Text);
                lviEmployeeRecords.SubItems.Add(gender);
                lviEmployeeRecords.SubItems.Add(txtEmpNum.Text);
                lviEmployeeRecords.SubItems.Add(txtPosition.Text);
                listViewEmployees.Items.Add(lviEmployeeRecords);
                MessageBox.Show("Record added successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetRecords();
                txtEmpId.Focus();


            }
            catch
            {
                MessageBox.Show("Please fill in all the information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ResetRecords();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            clsEmployee clsEmployee = new clsEmployee();
            clsEmployee.EmpId = txtEmpId.Text;
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Update record?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    listViewEmployees.SelectedItems[0].Text = txtEmpId.Text;
                    listViewEmployees.SelectedItems[0].SubItems[1].Text = txtEmpName.Text;
                    listViewEmployees.SelectedItems[0].SubItems[2].Text = gender;
                    listViewEmployees.SelectedItems[0].SubItems[3].Text = txtEmpNum.Text;
                    listViewEmployees.SelectedItems[0].SubItems[4].Text = txtPosition.Text;
                    MessageBox.Show("Record updated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int i = listViewEmployees.CheckedItems.Count;// total num of checked items
                if (i >= 1)//at least one item checked
                {
                    if (MessageBox.Show($"Are you sure you want to delete {i} item(s)?", "Confirm",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        foreach (ListViewItem lvitem in listViewEmployees.Items)
                        {
                            if (lvitem.Checked)//check if item is checked
                            {
                                listViewEmployees.Items.Remove(lvitem);//remove item
                                MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }

                    }
                }
                else//no items checked
                {
                    MessageBox.Show("No items have been selected.Try Again!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Press save to save the selected data for use in other forms");
        }
    }
}
