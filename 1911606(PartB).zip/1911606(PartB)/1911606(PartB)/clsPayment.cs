﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1911606_PartB_
{
    public class clsPayment
    {
        public static string customerId { get; set; }
        public string bookPrice { get; set; }
        public string itemPrice { get; set; }
        public string Balance { get; set; }
    }
}
