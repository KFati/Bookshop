﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class StationaryStore : Form
    {
        List<clsItem> allItems = new List<clsItem>();
        string strFmt = "{0,-5}{1,12}{2,20}{3,22:N2}";
        public StationaryStore()
        {
            InitializeComponent();
        }
        
        private void StationaryStore_Load(object sender, EventArgs e)
        {
            txtItemId.Focus();
            listViewItems.CheckBoxes = true;
            listViewItems.FullRowSelect = true;
        }

        private void ClearTextboxes()
        {
            txtItemId.Clear();
            txtItemName.Clear();
            txtItemPrice.Clear();
            txtItemLeft.Clear();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                ListViewItem lviItemRecords = new ListViewItem(txtItemId.Text);
                lviItemRecords.SubItems.Add(txtItemName.Text);

                lviItemRecords.SubItems.Add(txtItemPrice.Text);
                lviItemRecords.SubItems.Add(txtItemLeft.Text);
                
                listViewItems.Items.Add(lviItemRecords);
               
                MessageBox.Show("Record added successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextboxes();
                txtItemId.Focus();


            }
            catch
            {
                MessageBox.Show("Please fill in all the information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Update record?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    listViewItems.SelectedItems[0].Text = txtItemId.Text;
                    listViewItems.SelectedItems[0].SubItems[1].Text = txtItemName.Text;
                    listViewItems.SelectedItems[0].SubItems[2].Text = txtItemPrice.Text;
                    listViewItems.SelectedItems[0].SubItems[3].Text = txtItemLeft.Text;
                    
                    MessageBox.Show("Record updated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int i = listViewItems.CheckedItems.Count;// total num of checked items
                if (i >= 1)//at least one item checked
                {
                    if (MessageBox.Show($"Are you sure you want to delete {i} item(s)?", "Confirm",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        foreach (ListViewItem lvitem in listViewItems.Items)
                        {
                            if (lvitem.Checked)//check if item is checked
                            {
                                listViewItems.Items.Remove(lvitem);//remove item
                                MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }

                    }
                }
                else//no items checked
                {
                    MessageBox.Show("No items have been selected.Try Again!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            ClearTextboxes();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            clsItem clsItem = new clsItem();
            clsItem.itemName = txtItemName.Text;
        }

        private void listViewItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (listViewItems.SelectedItems.Count > 0)
                {
                    ListViewItem item = listViewItems.SelectedItems[0];
                    txtItemId.Text = item.SubItems[0].Text;
                    txtItemName.Text = item.SubItems[1].Text;
                    txtItemPrice.Text = item.SubItems[2].Text;
                    txtItemLeft.Text = item.SubItems[3].Text;
                }
                else
                {
                    txtItemId.Text = string.Empty;
                    txtItemName.Text = string.Empty;
                    txtItemPrice.Text = string.Empty;
                    txtItemLeft.Text = string.Empty;
                }
            }

            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Press save to save the selected data for use in other forms");
        }
    }
}
