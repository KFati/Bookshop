﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class Payroll : Form
    {
        List<clsPayroll> allPayroll = new List<clsPayroll>();
        

        clsEmployee clsEmployee = new clsEmployee();
        public Payroll()
        {
            InitializeComponent();
        }

        private void Payroll_Load(object sender, EventArgs e)
        {
            string strFmt = "{0,-5}{1,12}{2,15:N2}";
            lstPayrollDetails.Items.Add(String.Format(strFmt, "EmpId", "transport", "salary"));

            txtEmpId.Focus();
            txtEmpId.Text = clsEmployee.EmpId;
        }


        private void lstPayrollDetails_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int Index = lstPayrollDetails.SelectedIndex;
                if (Index > 0)
                {
                    clsPayroll Payroll = allPayroll[Index - 1];
                    txtEmpId.Text = Payroll.employeeID;
                    txtTransport.Text = Payroll.Transport.ToString();
                    txtNumHours.Text = Payroll.NumOfHours.ToString();
                    txtPayRate.Text = Payroll.PayRate.ToString();
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        private void ResetRecords()
        {
            txtEmpId.Clear();
            txtNumHours.Clear();
            txtPayRate.Clear();
            txtTransport.Clear();
            txtEmpId.Focus();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            lstPayrollDetails.ClearSelected();

            int index = lstPayrollDetails.FindString(txtSearch.Text);

            if (index < 0)
            {
                MessageBox.Show("Record not found, please check again", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                lstPayrollDetails.Text = String.Empty;
            }
            else
            {
                lstPayrollDetails.SelectedIndex = index;
            }
        }

        private void txtEmpId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only numeric characters allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtTransport_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("Only numeric characters allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtNumHours_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("Only numeric characters allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtPayRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("Only numeric characters allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Search by employee ID only", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void BtnCompute_Click(object sender, EventArgs e)
        {
            try
            {
                string strFmt = "{0,-5}{1,12}{2,15:N2}";
                clsPayroll myPayroll = new clsPayroll();

                myPayroll.employeeID = txtEmpId.Text;
                myPayroll.Transport = double.Parse(txtTransport.Text);
                myPayroll.NumOfHours = double.Parse(txtNumHours.Text);
                myPayroll.PayRate = double.Parse(txtPayRate.Text);

                allPayroll.Add(myPayroll);

                string transport = $"Rs{myPayroll.Transport}";
                string salary = $"Rs{myPayroll.GetSalary()}";


                lstPayrollDetails.Items.Add(string.Format(strFmt, myPayroll.employeeID, transport, salary));

                ResetRecords();

                MessageBox.Show($"Salary computed successfully for employee ID {myPayroll.employeeID}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string strFmt = "{0,-5}{1,12}{2,15:N2}";
                if (MessageBox.Show($"Update details for employee ID {txtEmpId.Text}", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    clsPayroll P = allPayroll[lstPayrollDetails.SelectedIndex - 1];
                    P.employeeID = txtEmpId.Text;
                    P.Transport = double.Parse(txtTransport.Text);
                    P.NumOfHours = double.Parse(txtNumHours.Text);
                    P.PayRate = double.Parse(txtPayRate.Text);

                    allPayroll[lstPayrollDetails.SelectedIndex - 1] = P;

                    string transport = $"Rs{P.Transport}";
                    string salary = $"Rs{P.GetSalary()}";

                    lstPayrollDetails.Items.Insert(lstPayrollDetails.SelectedIndex + 1, string.Format(strFmt, P.employeeID, transport, salary));
                    lstPayrollDetails.Items.RemoveAt(lstPayrollDetails.SelectedIndex);

                    ResetRecords();

                    MessageBox.Show($"Details successfully updated for employee ID {txtEmpId.Text}", "Update success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show($"Delete record for employee ID {txtEmpId.Text}", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    allPayroll.RemoveAt(lstPayrollDetails.SelectedIndex - 1);
                    lstPayrollDetails.Items.RemoveAt(lstPayrollDetails.SelectedIndex);
                    ResetRecords();
                    MessageBox.Show($"Record successfully deleted for employee ID {txtEmpId.Text}", "Delete success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ResetRecords();
        }

        private void BtnNextRecord_Click(object sender, EventArgs e)
        {
            if (lstPayrollDetails.SelectedIndex < lstPayrollDetails.Items.Count - 1)
            {
                lstPayrollDetails.SelectedIndex = lstPayrollDetails.SelectedIndex + 1;
            }
        }

        private void BtnPreviousRecord_Click(object sender, EventArgs e)
        {
            if (lstPayrollDetails.SelectedIndex > 0)
            {
                lstPayrollDetails.SelectedIndex = lstPayrollDetails.SelectedIndex - 1;
            }
        }
    }
}
