﻿namespace _1911606_PartB_
{
    partial class Payroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lstPayrollDetails = new System.Windows.Forms.ListBox();
            this.txtPayRate = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNumHours = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTransport = new System.Windows.Forms.TextBox();
            this.txtEmpId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnClear = new FontAwesome.Sharp.IconButton();
            this.BtnDelete = new FontAwesome.Sharp.IconButton();
            this.BtnUpdate = new FontAwesome.Sharp.IconButton();
            this.BtnCompute = new FontAwesome.Sharp.IconButton();
            this.BtnNextRecord = new FontAwesome.Sharp.IconButton();
            this.BtnPreviousRecord = new FontAwesome.Sharp.IconButton();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Location = new System.Drawing.Point(612, 338);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 22);
            this.label4.TabIndex = 65;
            this.label4.Text = "Search record";
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.txtSearch.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.txtSearch.Location = new System.Drawing.Point(614, 383);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(122, 28);
            this.txtSearch.TabIndex = 64;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            this.txtSearch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSearch_KeyPress);
            // 
            // lstPayrollDetails
            // 
            this.lstPayrollDetails.FormattingEnabled = true;
            this.lstPayrollDetails.ItemHeight = 16;
            this.lstPayrollDetails.Location = new System.Drawing.Point(157, 452);
            this.lstPayrollDetails.Name = "lstPayrollDetails";
            this.lstPayrollDetails.Size = new System.Drawing.Size(400, 116);
            this.lstPayrollDetails.TabIndex = 60;
            this.lstPayrollDetails.SelectedIndexChanged += new System.EventHandler(this.lstPayrollDetails_SelectedIndexChanged);
            // 
            // txtPayRate
            // 
            this.txtPayRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.txtPayRate.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayRate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.txtPayRate.Location = new System.Drawing.Point(475, 229);
            this.txtPayRate.Name = "txtPayRate";
            this.txtPayRate.Size = new System.Drawing.Size(258, 28);
            this.txtPayRate.TabIndex = 58;
            this.txtPayRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPayRate_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Location = new System.Drawing.Point(153, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 22);
            this.label6.TabIndex = 57;
            this.label6.Text = "Pay rate :";
            // 
            // txtNumHours
            // 
            this.txtNumHours.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.txtNumHours.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumHours.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.txtNumHours.Location = new System.Drawing.Point(475, 173);
            this.txtNumHours.Name = "txtNumHours";
            this.txtNumHours.Size = new System.Drawing.Size(258, 28);
            this.txtNumHours.TabIndex = 56;
            this.txtNumHours.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumHours_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Location = new System.Drawing.Point(153, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(231, 22);
            this.label5.TabIndex = 55;
            this.label5.Text = "Number of Hours Worked:";
            // 
            // txtTransport
            // 
            this.txtTransport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.txtTransport.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTransport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.txtTransport.Location = new System.Drawing.Point(475, 117);
            this.txtTransport.Name = "txtTransport";
            this.txtTransport.Size = new System.Drawing.Size(258, 28);
            this.txtTransport.TabIndex = 54;
            this.txtTransport.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTransport_KeyPress);
            // 
            // txtEmpId
            // 
            this.txtEmpId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.txtEmpId.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmpId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.txtEmpId.Location = new System.Drawing.Point(475, 61);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.Size = new System.Drawing.Size(258, 28);
            this.txtEmpId.TabIndex = 53;
            this.txtEmpId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmpId_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(153, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 22);
            this.label2.TabIndex = 52;
            this.label2.Text = "Transport :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(153, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 22);
            this.label3.TabIndex = 51;
            this.label3.Text = "Employee ID:";
            // 
            // BtnClear
            // 
            this.BtnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(107)))), ((int)(((byte)(138)))));
            this.BtnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClear.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnClear.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClear.ForeColor = System.Drawing.Color.White;
            this.BtnClear.IconChar = FontAwesome.Sharp.IconChar.PaintBrush;
            this.BtnClear.IconColor = System.Drawing.Color.White;
            this.BtnClear.IconSize = 16;
            this.BtnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnClear.Location = new System.Drawing.Point(214, 376);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Rotation = 0D;
            this.BtnClear.Size = new System.Drawing.Size(141, 40);
            this.BtnClear.TabIndex = 71;
            this.BtnClear.Text = "Clear";
            this.BtnClear.UseVisualStyleBackColor = false;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(167)))), ((int)(((byte)(0)))), ((int)(((byte)(49)))));
            this.BtnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDelete.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnDelete.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelete.ForeColor = System.Drawing.Color.White;
            this.BtnDelete.IconChar = FontAwesome.Sharp.IconChar.Trash;
            this.BtnDelete.IconColor = System.Drawing.Color.White;
            this.BtnDelete.IconSize = 16;
            this.BtnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnDelete.Location = new System.Drawing.Point(361, 378);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Rotation = 0D;
            this.BtnDelete.Size = new System.Drawing.Size(141, 38);
            this.BtnDelete.TabIndex = 70;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.UseVisualStyleBackColor = false;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(83)))), ((int)(((byte)(28)))));
            this.BtnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnUpdate.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnUpdate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnUpdate.ForeColor = System.Drawing.Color.White;
            this.BtnUpdate.IconChar = FontAwesome.Sharp.IconChar.PencilAlt;
            this.BtnUpdate.IconColor = System.Drawing.Color.White;
            this.BtnUpdate.IconSize = 16;
            this.BtnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnUpdate.Location = new System.Drawing.Point(361, 322);
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.Rotation = 0D;
            this.BtnUpdate.Size = new System.Drawing.Size(141, 38);
            this.BtnUpdate.TabIndex = 69;
            this.BtnUpdate.Text = "Update";
            this.BtnUpdate.UseVisualStyleBackColor = false;
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // BtnCompute
            // 
            this.BtnCompute.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(184)))), ((int)(((byte)(74)))));
            this.BtnCompute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCompute.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnCompute.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCompute.ForeColor = System.Drawing.Color.White;
            this.BtnCompute.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.BtnCompute.IconColor = System.Drawing.Color.White;
            this.BtnCompute.IconSize = 16;
            this.BtnCompute.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCompute.Location = new System.Drawing.Point(214, 322);
            this.BtnCompute.Name = "BtnCompute";
            this.BtnCompute.Rotation = 0D;
            this.BtnCompute.Size = new System.Drawing.Size(141, 38);
            this.BtnCompute.TabIndex = 68;
            this.BtnCompute.Text = "Compute";
            this.BtnCompute.UseVisualStyleBackColor = false;
            this.BtnCompute.Click += new System.EventHandler(this.BtnCompute_Click);
            // 
            // BtnNextRecord
            // 
            this.BtnNextRecord.BackColor = System.Drawing.Color.SkyBlue;
            this.BtnNextRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnNextRecord.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnNextRecord.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNextRecord.ForeColor = System.Drawing.Color.White;
            this.BtnNextRecord.IconChar = FontAwesome.Sharp.IconChar.AngleDoubleRight;
            this.BtnNextRecord.IconColor = System.Drawing.Color.White;
            this.BtnNextRecord.IconSize = 16;
            this.BtnNextRecord.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnNextRecord.Location = new System.Drawing.Point(584, 452);
            this.BtnNextRecord.Name = "BtnNextRecord";
            this.BtnNextRecord.Rotation = 0D;
            this.BtnNextRecord.Size = new System.Drawing.Size(193, 38);
            this.BtnNextRecord.TabIndex = 72;
            this.BtnNextRecord.Text = "Next Record";
            this.BtnNextRecord.UseVisualStyleBackColor = false;
            this.BtnNextRecord.Click += new System.EventHandler(this.BtnNextRecord_Click);
            // 
            // BtnPreviousRecord
            // 
            this.BtnPreviousRecord.BackColor = System.Drawing.Color.SkyBlue;
            this.BtnPreviousRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPreviousRecord.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnPreviousRecord.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPreviousRecord.ForeColor = System.Drawing.Color.White;
            this.BtnPreviousRecord.IconChar = FontAwesome.Sharp.IconChar.AngleDoubleLeft;
            this.BtnPreviousRecord.IconColor = System.Drawing.Color.White;
            this.BtnPreviousRecord.IconSize = 16;
            this.BtnPreviousRecord.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPreviousRecord.Location = new System.Drawing.Point(584, 513);
            this.BtnPreviousRecord.Name = "BtnPreviousRecord";
            this.BtnPreviousRecord.Rotation = 0D;
            this.BtnPreviousRecord.Size = new System.Drawing.Size(193, 38);
            this.BtnPreviousRecord.TabIndex = 73;
            this.BtnPreviousRecord.Text = "Previous Record";
            this.BtnPreviousRecord.UseVisualStyleBackColor = false;
            this.BtnPreviousRecord.Click += new System.EventHandler(this.BtnPreviousRecord_Click);
            // 
            // Payroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(59)))), ((int)(((byte)(78)))));
            this.ClientSize = new System.Drawing.Size(891, 621);
            this.Controls.Add(this.BtnPreviousRecord);
            this.Controls.Add(this.BtnNextRecord);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.BtnUpdate);
            this.Controls.Add(this.BtnCompute);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lstPayrollDetails);
            this.Controls.Add(this.txtPayRate);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtNumHours);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtTransport);
            this.Controls.Add(this.txtEmpId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Name = "Payroll";
            this.Text = "Payroll";
            this.Load += new System.EventHandler(this.Payroll_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ListBox lstPayrollDetails;
        private System.Windows.Forms.TextBox txtPayRate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNumHours;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTransport;
        private System.Windows.Forms.TextBox txtEmpId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private FontAwesome.Sharp.IconButton BtnClear;
        private FontAwesome.Sharp.IconButton BtnDelete;
        private FontAwesome.Sharp.IconButton BtnUpdate;
        private FontAwesome.Sharp.IconButton BtnCompute;
        private FontAwesome.Sharp.IconButton BtnNextRecord;
        private FontAwesome.Sharp.IconButton BtnPreviousRecord;
    }
}