﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class BookStore : Form
    {
       
        string Available = "";
        public BookStore()
        {
            InitializeComponent();
        }

        private void BookStore_Load(object sender, EventArgs e)
        {
            txtISBN.Focus();
            listViewBooks.CheckBoxes = true;
            listViewBooks.FullRowSelect = true;
        }

        private void radYes_CheckedChanged(object sender, EventArgs e)
        {
            Available = "Yes";
        }

        private void radNo_CheckedChanged(object sender, EventArgs e)
        {
            Available = "No";
        }

        private void ClearTextboxes()
        {
            txtISBN.Clear();
            txtTitle.Clear();
            txtAuthor.Clear();
            txtBookPrice.Clear();
            txtnumLeft.Clear();
        }

        private void listViewBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (listViewBooks.SelectedItems.Count > 0)
                {
                    ListViewItem book = listViewBooks.SelectedItems[0];
                    txtISBN.Text = book.SubItems[0].Text;
                    txtTitle.Text = book.SubItems[1].Text;
                    txtAuthor.Text = book.SubItems[2].Text;
                    txtBookPrice.Text = book.SubItems[3].Text;
                    txtnumLeft.Text = book.SubItems[4].Text;
                    Available = book.SubItems[5].Text;
                }
                if (Available.Equals("Yes"))
                {
                    radYes.Checked = true;
                }
                else if (Available.Equals("No"))
                {
                    radNo.Checked = true;
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                ListViewItem lviBookRecords = new ListViewItem(txtISBN.Text);
                lviBookRecords.SubItems.Add(txtTitle.Text);
                lviBookRecords.SubItems.Add(txtAuthor.Text);
                lviBookRecords.SubItems.Add(txtBookPrice.Text);
                lviBookRecords.SubItems.Add(txtnumLeft.Text);
                lviBookRecords.SubItems.Add(Available);
                listViewBooks.Items.Add(lviBookRecords);
                
                MessageBox.Show("Record added successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextboxes();
                txtISBN.Focus();
            }
            catch
            {
                MessageBox.Show("Please fill in all the information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int i = listViewBooks.CheckedItems.Count;// total num of checked items
                if (i >= 1)//at least one item checked
                {
                    if (MessageBox.Show($"Are you sure you want to delete {i} item(s)?", "Confirm",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        foreach (ListViewItem lvitem in listViewBooks.Items)
                        {
                            if (lvitem.Checked)//check if item is checked
                            {
                                listViewBooks.Items.Remove(lvitem);//remove item
                                MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }

                    }
                }
                else//no items checked
                {
                    MessageBox.Show("No items have been selected.Try Again!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Update record?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    listViewBooks.SelectedItems[0].Text = txtISBN.Text;
                    listViewBooks.SelectedItems[0].SubItems[1].Text = txtTitle.Text;
                    listViewBooks.SelectedItems[0].SubItems[2].Text = txtAuthor.Text;
                    listViewBooks.SelectedItems[0].SubItems[3].Text = txtBookPrice.Text;
                    listViewBooks.SelectedItems[0].SubItems[4].Text = txtnumLeft.Text;
                    listViewBooks.SelectedItems[0].SubItems[5].Text = Available;
                    MessageBox.Show("Record updated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ClearTextboxes();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            clsBook clsBook = new clsBook();
            clsBook.bookTitle = txtTitle.Text;
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Press save to save the selected data for use in other forms");
        }
    }
}
