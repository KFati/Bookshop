﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1911606_PartB_
{
    public class clsPayroll
    {
        private double _PayRate, _HoursWorked, _Salary, _Transport;
        private string _EmpID;

        public double GetSalary()
        {
            double Salary = (_PayRate * _HoursWorked) + _Transport;
            return Salary;
        }

        public double Salary
        {
            get
            {
                return _Salary;
            }
            set
            {
                _Salary = value;
            }
        }
        public string employeeID
        {
            get
            {
                return _EmpID;
            }
            set
            {
                _EmpID = value;
            }
        }
        public double Transport
        {
            get
            {
                return _Transport;
            }
            set
            {
                _Transport = value;
            }
        }
        public double NumOfHours
        {
            get
            {
                return _HoursWorked;
            }
            set
            {
                _HoursWorked = value;
            }
        }
        public double PayRate
        {
            get
            {
                return _PayRate;
            }
            set
            {
                _PayRate = value;
            }
        }
    }
}
