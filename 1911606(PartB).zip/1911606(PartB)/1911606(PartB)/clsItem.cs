﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1911606_PartB_
{
    public class clsItem
    {
        public string itemId { get; set; }
        public static string itemName { get; set; }
        public string itemPrice { get; set; }
        public string itemLeft { get; set; }
    }
}
