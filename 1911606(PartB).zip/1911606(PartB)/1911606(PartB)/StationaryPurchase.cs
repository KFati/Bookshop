﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{

    public partial class StationaryPurchase : Form
    {
        public static decimal itemTotalPrice = 0;
        public StationaryPurchase()
        {
            InitializeComponent();
            chkCopybook.CheckedChanged += Calculate;
            chkPen.CheckedChanged += Calculate;
            chkNotebooks.CheckedChanged += Calculate;
            chkPencils.CheckedChanged += Calculate;
            chkPaint.CheckedChanged += Calculate;
            chkSlate.CheckedChanged += Calculate;
            chkEraser.CheckedChanged += Calculate;
            chkSharpener.CheckedChanged += Calculate;
            chkFiles.CheckedChanged += Calculate;
            chkPapers.CheckedChanged += Calculate;
            chkColour.CheckedChanged += Calculate;
            chkDrawing.CheckedChanged += Calculate;
            chkRulers.CheckedChanged += Calculate;
            chkMechanical.CheckedChanged += Calculate;
            numCopybook.Click += Calculate;
            numPen.Click += Calculate;
            numNotebook.Click += Calculate;
            numPencil.Click += Calculate;
            numPaint.Click += Calculate;
            numSlate.Click += Calculate;
            numErasers.Click += Calculate;
            numSharpeners.Click += Calculate;
            numFiles.Click += Calculate;
            numPapers.Click += Calculate;
            numColour.Click += Calculate;
            numDrawing.Click += Calculate;
            numRulers.Click += Calculate;
            numMechanical.Click += Calculate;
        }

        decimal NoCopybook = 0;
        decimal NoPen = 0;
        decimal NoNotebook = 0;
        decimal NoPencil = 0;
        decimal NoPaint = 0;
        decimal NoSlate = 0;
        decimal NoEraser = 0;
        decimal NoSharpener = 0;
        decimal NoFiles = 0;
        decimal NoPapers = 0;
        decimal NoColour = 0;
        decimal NoDrawing = 0;
        decimal NoRuler = 0;
        decimal NoMechanical = 0;

        private void Calculate(Object sender, EventArgs e)
        {
            decimal totalPrice = 0;
            if (chkCopybook.Checked)
            {
                NoCopybook = numCopybook.Value;
                totalPrice += NoCopybook * 20;
            }

            if (chkPen.Checked)
            {
                NoPen = numPen.Value;
                totalPrice += NoPen * 10;
            }

            if (chkNotebooks.Checked)
            {
                NoNotebook = numNotebook.Value;
                totalPrice += NoNotebook * 30;
            }

            if (chkPencils.Checked)
            {
                NoPencil = numPencil.Value;
                totalPrice += NoPencil * 10;
            }

            if (chkPaint.Checked)
            {
                NoPaint = numPaint.Value;
                totalPrice += NoPaint * 50;
            }

            if (chkSlate.Checked)
            {
                NoSlate = numSlate.Value;
                totalPrice += NoSlate * 20;
            }

            if (chkEraser.Checked)
            {
                NoEraser = numErasers.Value;
                totalPrice += NoEraser * 10;
            }

            if (chkSharpener.Checked)
            {
                NoSharpener = numSharpeners.Value;
                totalPrice += NoSharpener * 15;
            }

            if (chkFiles.Checked)
            {
                NoFiles = numFiles.Value;
                totalPrice += NoFiles * 70;
            }

            if (chkPapers.Checked)
            {
                NoPapers = numPapers.Value;
                totalPrice += NoPapers * 10;
            }

            if (chkColour.Checked)
            {
                NoColour = numColour.Value;
                totalPrice += NoColour * 50;
            }

            if (chkDrawing.Checked)
            {
                NoDrawing = numDrawing.Value;
                totalPrice += NoDrawing * 10;
            }

            if (chkRulers.Checked)
            {
                NoRuler = numRulers.Value;
                totalPrice += NoRuler * 10;
            }

            if (chkMechanical.Checked)
            {
                NoMechanical = numMechanical.Value;
                totalPrice += NoMechanical * 10;
            }

            string TOTALPRICE = $"Rs {totalPrice}";

            txtItemPrice.Text = TOTALPRICE.ToString();
            itemTotalPrice = totalPrice;
        }
    }
            
        

       
    
}
