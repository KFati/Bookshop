﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class Payment : Form
    {
        List<clsPayment> allPayment = new List<clsPayment>();
        string strFmt = "{0,-5}";
        public Payment()
        {
            InitializeComponent();
        }  
        clsPayment clsPayment = new clsPayment();
        private void Payment_Load(object sender, EventArgs e)
        {
            lstPayment.Items.Add(String.Format(strFmt, "Total Price"));

            txtCustomerId.Text = clsPayment.customerId;

            txtBookPrice.Text = BookPurchase.totalBookPrice.ToString();
            txtItemPrice.Text = StationaryPurchase.itemTotalPrice.ToString();
            lblDate.Text = DateTime.Now.ToString("dd MMMM,yyyy");
            txtReceiptBook.Text = BookPurchase.totalBookPrice.ToString();
            txtReceiptItem.Text = StationaryPurchase.itemTotalPrice.ToString();
        }
            
        

        private void BtnTotal_Click(object sender, EventArgs e)
        {
            int books = int.Parse(txtBookPrice.Text);
            int items = int.Parse(txtItemPrice.Text);

            double subtotal = 0, vat = 0, total = 0;
            Compute(books, items, ref subtotal, ref vat, ref total);

            string SUB = $"Rs {subtotal}";
            string VAT15 = $"Rs {vat}";
            string TOTAL = $"Rs {total}";

            txtSubTotal.Text = SUB.ToString();
            txtVat.Text = VAT15.ToString();
            txtTotalPrice.Text = TOTAL.ToString();

            txtReceiptSubTotal.Text = txtSubTotal.Text;
            txtReceiptVat.Text = txtVat.Text;
            txtReceiptTotalPrice.Text = txtTotalPrice.Text;
        }


        private void Compute(int books, int items, ref double subtotal, ref double vat, ref double total)
        {
            subtotal = books + items;
            vat = .15 * subtotal;
            total = subtotal + vat;
        }

        private void Doc_PrintPage(object sender, PrintPageEventArgs e)
        {
            float x = e.MarginBounds.Left;
            float y = e.MarginBounds.Top;
            Bitmap bmp = new Bitmap(this.panel2.Width, this.panel2.Height);
            this.panel2.DrawToBitmap(bmp, new Rectangle(0, 0, this.panel2.Width, this.panel2.Height));
            e.Graphics.DrawImage((Image)bmp, x, y);
        }

        private void BtnPayment_Click(object sender, EventArgs e)
        {
            string paymentMethod;
            if (radCreditCard.Checked)
            {
                paymentMethod = "Credit Card";
                if (MessageBox.Show("Print Receipt", "Receipt", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    PrintDocument doc = new PrintDocument();
                    doc.PrintPage += this.Doc_PrintPage;
                    PrintDialog dlgSettings = new PrintDialog();
                    dlgSettings.Document = doc;
                    if (dlgSettings.ShowDialog() == DialogResult.OK)
                    {
                        doc.Print();
                    }
                }
            }

            else if (radMCBJuice.Checked)
            {
                paymentMethod = "MCB Juice";
                MessageBox.Show("101030300200000", "Office World’s Account Number", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else if (radCash.Checked)
            {
                paymentMethod = "Cash";
                if (MessageBox.Show("Print Receipt", "Receipt", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    System.Drawing.Printing.PrintDocument doc = new PrintDocument();
                    doc.PrintPage += this.Doc_PrintPage;
                    PrintDialog dlgSettings = new PrintDialog();
                    dlgSettings.Document = doc;
                    if (dlgSettings.ShowDialog() == DialogResult.OK)
                    {
                        doc.Print();
                    }
                }
            }

            if (MessageBox.Show("Do you want to exit the application?", "Transaction Complete", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string strFmt = "{0,-5}";
                clsPayment myPayment= new clsPayment();

                myPayment.bookPrice = txtBookPrice.Text;
                myPayment.itemPrice = txtItemPrice.Text;
                myPayment.Balance = txtTotalPrice.Text;

               
                allPayment.Add(myPayment);
                lstPayment.Items.Add(string.Format(strFmt, myPayment.Balance.ToString()));
                //ClearTextBoxes();

                MessageBox.Show("Data added successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string strFmt = "{0,-5}";
                if (MessageBox.Show($"Update details for payment?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    clsPayment P = allPayment[lstPayment.SelectedIndex - 1];
                    P.bookPrice = txtBookPrice.Text;
                    P.itemPrice = txtItemPrice.Text;
                    P.Balance = txtTotalPrice.Text;

                    allPayment[lstPayment.SelectedIndex - 1] = P;

                    lstPayment.Items.Insert(lstPayment.SelectedIndex + 1, string.Format(strFmt, P.Balance.ToString()));
                    lstPayment.Items.RemoveAt(lstPayment.SelectedIndex);

                    //ClearTextBoxes();

                    MessageBox.Show($"Details successfully updated !", "Update success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Delete record ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    allPayment.RemoveAt(lstPayment.SelectedIndex - 1);
                    lstPayment.Items.RemoveAt(lstPayment.SelectedIndex);

                    ClearTextBoxes();
                    MessageBox.Show("Record deleted successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
        }
        private void ClearTextBoxes()
        {
            txtCustomerId.Clear();
            txtBookPrice.Clear();
            txtItemPrice.Clear();
            txtSubTotal.Clear();
            txtVat.Clear();
            txtTotalPrice.Clear();
        }

        private void lstPayment_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int Index = lstPayment.SelectedIndex;
                if (Index > 0)
                {
                    clsPayment payment = allPayment[Index - 1];
                    
                    txtBookPrice.Text = payment.bookPrice;
                    txtItemPrice.Text = payment.itemPrice;
                    
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
