﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class Delivery : Form
    {
        List<clsDelivery> allDelivery = new List<clsDelivery>();
        string strFmt = "{0,-5}{1,12}{2,15}";
        int days;
        DateTime startDate;
        DateTime endDate;
        public Delivery()
        {
            InitializeComponent();
        }

        clsBook clsBook = new clsBook();
        private void Delivery_Load(object sender, EventArgs e)
        {
            lstDelivery.Items.Add(String.Format(strFmt, "Book", "Item", "Days"));
            txtTitle.Text = clsBook.bookTitle;
            txtItem.Text = clsItem.itemName;
        }

        private void lstDelivery_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int Index = lstDelivery.SelectedIndex;
                if (Index > 0)
                {
                    clsDelivery Delivery = allDelivery[Index - 1];
                    txtTitle.Text = Delivery.bookTitle;
                    txtItem.Text = Delivery.itemName;
                    txtAddress.Text = Delivery.Address;

                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void ResetRecords()
        {
            txtTitle.Clear();
            txtItem.Clear();
            txtAddress.Clear();
            txtTitle.Focus();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string strFmt = "{0,-5}{1,12}{2,15:N2}";
                clsDelivery myDelivery = new clsDelivery();

                myDelivery.bookTitle = txtTitle.Text;
                myDelivery.itemName = txtItem.Text;
                myDelivery.Address = txtAddress.Text;
                myDelivery.orderDate = dtOrder.Text;
                myDelivery.deliveryDate = dtDelivery.Text;

                startDate = dtOrder.Value.Date;
                endDate = dtDelivery.Value.Date;

                days = clsDelivery.CalulateDeliveryDays(startDate, endDate);
                allDelivery.Add(myDelivery);
                lstDelivery.Items.Add(string.Format(strFmt, myDelivery.bookTitle, myDelivery.itemName, days.ToString()));
                ResetRecords();

                MessageBox.Show("Data added successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Please fill in all the information.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string strFmt = "{0,-5}{1,12}{2,15:N2}";
                if (MessageBox.Show($"Update details for delivery?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    clsDelivery D = allDelivery[lstDelivery.SelectedIndex - 1];
                    D.bookTitle = txtTitle.Text;
                    D.itemName = txtItem.Text;
                    D.Address = txtAddress.Text;
                    D.orderDate = dtOrder.Text;
                    D.deliveryDate = dtDelivery.Text;

                    allDelivery[lstDelivery.SelectedIndex - 1] = D;

                    days = clsDelivery.CalulateDeliveryDays(startDate, endDate);

                    lstDelivery.Items.Insert(lstDelivery.SelectedIndex + 1, string.Format(strFmt, D.bookTitle, D.itemName, days.ToString()));
                    lstDelivery.Items.RemoveAt(lstDelivery.SelectedIndex);

                    ResetRecords();

                    MessageBox.Show($"Details successfully updated !", "Update success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Delete record ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    allDelivery.RemoveAt(lstDelivery.SelectedIndex - 1);
                    lstDelivery.Items.RemoveAt(lstDelivery.SelectedIndex);

                    ResetRecords();
                    MessageBox.Show("Record deleted successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("Error!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ResetRecords();
        }

        
    }
}
