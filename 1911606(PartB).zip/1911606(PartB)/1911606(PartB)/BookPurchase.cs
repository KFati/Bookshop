﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class BookPurchase : Form
    {
        public static decimal totalBookPrice = 0;
        public BookPurchase()
        {
            InitializeComponent();
            chkLastAct.CheckedChanged += Compute;
            chkDavinci.CheckedChanged += Compute;
            chkDarkWitch.CheckedChanged += Compute;
            chkAlchemist.CheckedChanged += Compute;
            chkTom.CheckedChanged += Compute;
            chkHarry.CheckedChanged += Compute;
            chkMortal.CheckedChanged += Compute;
            chkNancy.CheckedChanged += Compute;
            chkTwilight.CheckedChanged += Compute;
            chkFearless.CheckedChanged += Compute;
        }

        private void Clear()
        {
            chkLastAct.Checked = false;
            chkDavinci.Checked = false;
            chkDarkWitch.Checked = false;
            chkAlchemist.Checked = false;
            chkTom.Checked = false;
            chkHarry.Checked = false;
            chkMortal.Checked = false;
            chkNancy.Checked = false;
            chkTwilight.Checked = false;
            chkFearless.Checked = false;
        }

        private void checkbox()
        {
            int numberChecked = 0;
            CheckBox[] array = new CheckBox[] { chkLastAct, chkDavinci, chkDarkWitch, chkAlchemist,
                                                chkTom, chkHarry,chkMortal, chkNancy,
                                                chkNancy,chkTwilight,chkFearless};

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i].Checked)
                    numberChecked++;
            }

            if (numberChecked > 4)
            {
                MessageBox.Show("Please select only 4 books", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Clear();
            }
        }

        private void chkLastAct_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkDavinci_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkDarkWitch_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkAlchemist_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkTom_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkHarry_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkMortal_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkNancy_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkTwilight_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void chkFearless_CheckedChanged(object sender, EventArgs e)
        {
            checkbox();
        }

        private void Compute(object sender, EventArgs e)
        {
            decimal total = 0;

            if (chkLastAct.Checked)
                total += 200;

            if (chkDavinci.Checked)
                total += 250;

            if (chkDarkWitch.Checked)
                total += 300;

            if (chkAlchemist.Checked)
                total += 200;

            if (chkTom.Checked)
                total += 100;

            if (chkHarry.Checked)
                total += 500;

            if (chkMortal.Checked)
                total += 600;

            if (chkNancy.Checked)
                total += 350;

            if (chkTwilight.Checked)
                total += 400;

            if (chkFearless.Checked)
                total += 650;

            string TOTAL = $"Rs {total}";


            txtPrice.Text = TOTAL.ToString();
            totalBookPrice = total;
        }

        
    }
}
