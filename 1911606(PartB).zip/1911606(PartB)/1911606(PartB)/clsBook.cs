﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1911606_PartB_
{
    public class clsBook
    {
        public string ISBN { get; set; }
        public static string bookTitle { get; set; }
        public string author { get; set; }
        public int bookPrice { get; set; }
        public string isAvailable { get; set; }
        public int numLeft { get; set; }
    }
}
