﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1911606_PartB_
{
    public class clsDelivery
    {

        public  string bookTitle { get; set; }
        public  string itemName { get; set; }
        public string Address { get; set; }
        public string orderDate { get; set; }
        public string deliveryDate { get; set; }
        public int numOfDays { get; set; }

        public static int CalulateDeliveryDays(System.DateTime StartDate, System.DateTime EndDate)
        {
            int days = 0;
            System.TimeSpan ts = new TimeSpan(EndDate.Ticks - StartDate.Ticks);
            days = (int)(ts.Days + 1);
            return days;

        }

    }

    
}
