﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1911606_PartB_
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        //ARRAY
        string[] usernames = { "Fatima" };
        string[] passwords = { "Fatima123" };

        private void chkShow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShow.Checked)
            {
                txtPassword.UseSystemPasswordChar = false;
                var checkbox = (CheckBox)sender;
                chkShow.Text = "Hide password";
            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;
                var checkbox = (CheckBox)sender;
                chkShow.Text = "Show password";
            }
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if ((usernames.Contains(txtUsername.Text) && passwords.Contains(txtPassword.Text) && Array.IndexOf(usernames, txtUsername.Text) == Array.IndexOf(passwords, txtPassword.Text)))
            {
                MessageBox.Show("Login Successful", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);
                OfficeWorld myForm = new OfficeWorld();
                myForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid username/password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            txtUsername.Focus();
            label4.Text = DateTime.Now.ToString("dd MMMM,yyyy");
            label3.Text = DateTime.Now.ToLongTimeString();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtUsername_Validating(object sender, CancelEventArgs e)
        {
            if (txtUsername.Text == string.Empty)
            {
                errorProvider1.SetError(txtUsername, "Please Enter Username");
            }
            else
            {
                errorProvider1.SetError(txtUsername, "");
            }
        }

        private void txtPassword_Validating(object sender, CancelEventArgs e)
        {
            if (txtPassword.Text == string.Empty)
            {
                errorProvider1.SetError(txtPassword, "Please Enter Password");
            }
            else
            {
                errorProvider1.SetError(txtPassword, "");
            }
        }
    }
}
