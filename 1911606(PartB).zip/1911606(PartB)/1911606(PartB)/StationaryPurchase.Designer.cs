﻿namespace _1911606_PartB_
{
    partial class StationaryPurchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numMechanical = new System.Windows.Forms.NumericUpDown();
            this.numRulers = new System.Windows.Forms.NumericUpDown();
            this.numDrawing = new System.Windows.Forms.NumericUpDown();
            this.numColour = new System.Windows.Forms.NumericUpDown();
            this.numPapers = new System.Windows.Forms.NumericUpDown();
            this.numFiles = new System.Windows.Forms.NumericUpDown();
            this.numSharpeners = new System.Windows.Forms.NumericUpDown();
            this.numErasers = new System.Windows.Forms.NumericUpDown();
            this.numSlate = new System.Windows.Forms.NumericUpDown();
            this.numPaint = new System.Windows.Forms.NumericUpDown();
            this.numPencil = new System.Windows.Forms.NumericUpDown();
            this.numNotebook = new System.Windows.Forms.NumericUpDown();
            this.numPen = new System.Windows.Forms.NumericUpDown();
            this.numCopybook = new System.Windows.Forms.NumericUpDown();
            this.chkMechanical = new System.Windows.Forms.CheckBox();
            this.chkColour = new System.Windows.Forms.CheckBox();
            this.chkPapers = new System.Windows.Forms.CheckBox();
            this.chkFiles = new System.Windows.Forms.CheckBox();
            this.chkSharpener = new System.Windows.Forms.CheckBox();
            this.chkEraser = new System.Windows.Forms.CheckBox();
            this.chkRulers = new System.Windows.Forms.CheckBox();
            this.chkSlate = new System.Windows.Forms.CheckBox();
            this.chkPaint = new System.Windows.Forms.CheckBox();
            this.chkDrawing = new System.Windows.Forms.CheckBox();
            this.chkPencils = new System.Windows.Forms.CheckBox();
            this.chkNotebooks = new System.Windows.Forms.CheckBox();
            this.chkPen = new System.Windows.Forms.CheckBox();
            this.chkCopybook = new System.Windows.Forms.CheckBox();
            this.txtItemPrice = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numMechanical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRulers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDrawing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPapers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFiles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSharpeners)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numErasers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSlate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPaint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPencil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNotebook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCopybook)).BeginInit();
            this.SuspendLayout();
            // 
            // numMechanical
            // 
            this.numMechanical.Location = new System.Drawing.Point(704, 407);
            this.numMechanical.Name = "numMechanical";
            this.numMechanical.Size = new System.Drawing.Size(36, 22);
            this.numMechanical.TabIndex = 85;
            // 
            // numRulers
            // 
            this.numRulers.Location = new System.Drawing.Point(704, 355);
            this.numRulers.Name = "numRulers";
            this.numRulers.Size = new System.Drawing.Size(36, 22);
            this.numRulers.TabIndex = 84;
            // 
            // numDrawing
            // 
            this.numDrawing.Location = new System.Drawing.Point(704, 308);
            this.numDrawing.Name = "numDrawing";
            this.numDrawing.Size = new System.Drawing.Size(36, 22);
            this.numDrawing.TabIndex = 83;
            // 
            // numColour
            // 
            this.numColour.Location = new System.Drawing.Point(704, 259);
            this.numColour.Name = "numColour";
            this.numColour.Size = new System.Drawing.Size(36, 22);
            this.numColour.TabIndex = 82;
            // 
            // numPapers
            // 
            this.numPapers.Location = new System.Drawing.Point(704, 204);
            this.numPapers.Name = "numPapers";
            this.numPapers.Size = new System.Drawing.Size(36, 22);
            this.numPapers.TabIndex = 81;
            // 
            // numFiles
            // 
            this.numFiles.Location = new System.Drawing.Point(704, 155);
            this.numFiles.Name = "numFiles";
            this.numFiles.Size = new System.Drawing.Size(36, 22);
            this.numFiles.TabIndex = 80;
            // 
            // numSharpeners
            // 
            this.numSharpeners.Location = new System.Drawing.Point(704, 113);
            this.numSharpeners.Name = "numSharpeners";
            this.numSharpeners.Size = new System.Drawing.Size(36, 22);
            this.numSharpeners.TabIndex = 79;
            // 
            // numErasers
            // 
            this.numErasers.Location = new System.Drawing.Point(352, 408);
            this.numErasers.Name = "numErasers";
            this.numErasers.Size = new System.Drawing.Size(36, 22);
            this.numErasers.TabIndex = 78;
            // 
            // numSlate
            // 
            this.numSlate.Location = new System.Drawing.Point(352, 356);
            this.numSlate.Name = "numSlate";
            this.numSlate.Size = new System.Drawing.Size(36, 22);
            this.numSlate.TabIndex = 77;
            // 
            // numPaint
            // 
            this.numPaint.Location = new System.Drawing.Point(352, 305);
            this.numPaint.Name = "numPaint";
            this.numPaint.Size = new System.Drawing.Size(36, 22);
            this.numPaint.TabIndex = 76;
            // 
            // numPencil
            // 
            this.numPencil.Location = new System.Drawing.Point(352, 256);
            this.numPencil.Name = "numPencil";
            this.numPencil.Size = new System.Drawing.Size(36, 22);
            this.numPencil.TabIndex = 75;
            // 
            // numNotebook
            // 
            this.numNotebook.Location = new System.Drawing.Point(352, 209);
            this.numNotebook.Name = "numNotebook";
            this.numNotebook.Size = new System.Drawing.Size(36, 22);
            this.numNotebook.TabIndex = 74;
            // 
            // numPen
            // 
            this.numPen.Location = new System.Drawing.Point(352, 156);
            this.numPen.Name = "numPen";
            this.numPen.Size = new System.Drawing.Size(36, 22);
            this.numPen.TabIndex = 73;
            // 
            // numCopybook
            // 
            this.numCopybook.Location = new System.Drawing.Point(352, 113);
            this.numCopybook.Name = "numCopybook";
            this.numCopybook.Size = new System.Drawing.Size(36, 22);
            this.numCopybook.TabIndex = 72;
            // 
            // chkMechanical
            // 
            this.chkMechanical.AutoSize = true;
            this.chkMechanical.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMechanical.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkMechanical.Location = new System.Drawing.Point(444, 407);
            this.chkMechanical.Name = "chkMechanical";
            this.chkMechanical.Size = new System.Drawing.Size(183, 26);
            this.chkMechanical.TabIndex = 71;
            this.chkMechanical.Text = "Mechanical Pencil";
            this.chkMechanical.UseVisualStyleBackColor = true;
            // 
            // chkColour
            // 
            this.chkColour.AutoSize = true;
            this.chkColour.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkColour.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkColour.Location = new System.Drawing.Point(444, 255);
            this.chkColour.Name = "chkColour";
            this.chkColour.Size = new System.Drawing.Size(185, 26);
            this.chkColour.TabIndex = 70;
            this.chkColour.Text = "Coloured Crayons";
            this.chkColour.UseVisualStyleBackColor = true;
            // 
            // chkPapers
            // 
            this.chkPapers.AutoSize = true;
            this.chkPapers.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPapers.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkPapers.Location = new System.Drawing.Point(443, 204);
            this.chkPapers.Name = "chkPapers";
            this.chkPapers.Size = new System.Drawing.Size(93, 26);
            this.chkPapers.TabIndex = 69;
            this.chkPapers.Text = "Papers";
            this.chkPapers.UseVisualStyleBackColor = true;
            // 
            // chkFiles
            // 
            this.chkFiles.AutoSize = true;
            this.chkFiles.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkFiles.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkFiles.Location = new System.Drawing.Point(443, 155);
            this.chkFiles.Name = "chkFiles";
            this.chkFiles.Size = new System.Drawing.Size(73, 26);
            this.chkFiles.TabIndex = 68;
            this.chkFiles.Text = "Files";
            this.chkFiles.UseVisualStyleBackColor = true;
            // 
            // chkSharpener
            // 
            this.chkSharpener.AutoSize = true;
            this.chkSharpener.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSharpener.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkSharpener.Location = new System.Drawing.Point(443, 109);
            this.chkSharpener.Name = "chkSharpener";
            this.chkSharpener.Size = new System.Drawing.Size(130, 26);
            this.chkSharpener.TabIndex = 67;
            this.chkSharpener.Text = "Sharpeners";
            this.chkSharpener.UseVisualStyleBackColor = true;
            // 
            // chkEraser
            // 
            this.chkEraser.AutoSize = true;
            this.chkEraser.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEraser.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkEraser.Location = new System.Drawing.Point(151, 407);
            this.chkEraser.Name = "chkEraser";
            this.chkEraser.Size = new System.Drawing.Size(98, 26);
            this.chkEraser.TabIndex = 66;
            this.chkEraser.Text = "Erasers";
            this.chkEraser.UseVisualStyleBackColor = true;
            // 
            // chkRulers
            // 
            this.chkRulers.AutoSize = true;
            this.chkRulers.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRulers.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkRulers.Location = new System.Drawing.Point(443, 355);
            this.chkRulers.Name = "chkRulers";
            this.chkRulers.Size = new System.Drawing.Size(87, 26);
            this.chkRulers.TabIndex = 65;
            this.chkRulers.Text = "Rulers";
            this.chkRulers.UseVisualStyleBackColor = true;
            // 
            // chkSlate
            // 
            this.chkSlate.AutoSize = true;
            this.chkSlate.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSlate.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkSlate.Location = new System.Drawing.Point(151, 355);
            this.chkSlate.Name = "chkSlate";
            this.chkSlate.Size = new System.Drawing.Size(85, 26);
            this.chkSlate.TabIndex = 64;
            this.chkSlate.Text = "Slates";
            this.chkSlate.UseVisualStyleBackColor = true;
            // 
            // chkPaint
            // 
            this.chkPaint.AutoSize = true;
            this.chkPaint.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPaint.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkPaint.Location = new System.Drawing.Point(153, 304);
            this.chkPaint.Name = "chkPaint";
            this.chkPaint.Size = new System.Drawing.Size(74, 26);
            this.chkPaint.TabIndex = 63;
            this.chkPaint.Text = "Paint";
            this.chkPaint.UseVisualStyleBackColor = true;
            // 
            // chkDrawing
            // 
            this.chkDrawing.AutoSize = true;
            this.chkDrawing.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDrawing.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkDrawing.Location = new System.Drawing.Point(444, 304);
            this.chkDrawing.Name = "chkDrawing";
            this.chkDrawing.Size = new System.Drawing.Size(159, 26);
            this.chkDrawing.TabIndex = 62;
            this.chkDrawing.Text = "Drawing Books";
            this.chkDrawing.UseVisualStyleBackColor = true;
            // 
            // chkPencils
            // 
            this.chkPencils.AutoSize = true;
            this.chkPencils.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPencils.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkPencils.Location = new System.Drawing.Point(151, 255);
            this.chkPencils.Name = "chkPencils";
            this.chkPencils.Size = new System.Drawing.Size(94, 26);
            this.chkPencils.TabIndex = 61;
            this.chkPencils.Text = "Pencils";
            this.chkPencils.UseVisualStyleBackColor = true;
            // 
            // chkNotebooks
            // 
            this.chkNotebooks.AutoSize = true;
            this.chkNotebooks.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkNotebooks.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkNotebooks.Location = new System.Drawing.Point(151, 204);
            this.chkNotebooks.Name = "chkNotebooks";
            this.chkNotebooks.Size = new System.Drawing.Size(124, 26);
            this.chkNotebooks.TabIndex = 60;
            this.chkNotebooks.Text = "Notebooks";
            this.chkNotebooks.UseVisualStyleBackColor = true;
            // 
            // chkPen
            // 
            this.chkPen.AutoSize = true;
            this.chkPen.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPen.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkPen.Location = new System.Drawing.Point(151, 155);
            this.chkPen.Name = "chkPen";
            this.chkPen.Size = new System.Drawing.Size(76, 26);
            this.chkPen.TabIndex = 59;
            this.chkPen.Text = "Pens";
            this.chkPen.UseVisualStyleBackColor = true;
            // 
            // chkCopybook
            // 
            this.chkCopybook.AutoSize = true;
            this.chkCopybook.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCopybook.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chkCopybook.Location = new System.Drawing.Point(151, 109);
            this.chkCopybook.Name = "chkCopybook";
            this.chkCopybook.Size = new System.Drawing.Size(129, 26);
            this.chkCopybook.TabIndex = 58;
            this.chkCopybook.Text = "Copybooks";
            this.chkCopybook.UseVisualStyleBackColor = true;
            // 
            // txtItemPrice
            // 
            this.txtItemPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.txtItemPrice.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.txtItemPrice.Location = new System.Drawing.Point(438, 489);
            this.txtItemPrice.Name = "txtItemPrice";
            this.txtItemPrice.Size = new System.Drawing.Size(174, 28);
            this.txtItemPrice.TabIndex = 56;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(278, 493);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 19);
            this.label1.TabIndex = 55;
            this.label1.Text = "Total Item Price:";
            // 
            // StationaryPurchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(59)))), ((int)(((byte)(78)))));
            this.ClientSize = new System.Drawing.Size(891, 621);
            this.Controls.Add(this.numMechanical);
            this.Controls.Add(this.numRulers);
            this.Controls.Add(this.numDrawing);
            this.Controls.Add(this.numColour);
            this.Controls.Add(this.numPapers);
            this.Controls.Add(this.numFiles);
            this.Controls.Add(this.numSharpeners);
            this.Controls.Add(this.numErasers);
            this.Controls.Add(this.numSlate);
            this.Controls.Add(this.numPaint);
            this.Controls.Add(this.numPencil);
            this.Controls.Add(this.numNotebook);
            this.Controls.Add(this.numPen);
            this.Controls.Add(this.numCopybook);
            this.Controls.Add(this.chkMechanical);
            this.Controls.Add(this.chkColour);
            this.Controls.Add(this.chkPapers);
            this.Controls.Add(this.chkFiles);
            this.Controls.Add(this.chkSharpener);
            this.Controls.Add(this.chkEraser);
            this.Controls.Add(this.chkRulers);
            this.Controls.Add(this.chkSlate);
            this.Controls.Add(this.chkPaint);
            this.Controls.Add(this.chkDrawing);
            this.Controls.Add(this.chkPencils);
            this.Controls.Add(this.chkNotebooks);
            this.Controls.Add(this.chkPen);
            this.Controls.Add(this.chkCopybook);
            this.Controls.Add(this.txtItemPrice);
            this.Controls.Add(this.label1);
            this.Name = "StationaryPurchase";
            this.Text = "StationaryPurchase";
            ((System.ComponentModel.ISupportInitialize)(this.numMechanical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRulers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDrawing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPapers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFiles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSharpeners)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numErasers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSlate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPaint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPencil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNotebook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCopybook)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numMechanical;
        private System.Windows.Forms.NumericUpDown numRulers;
        private System.Windows.Forms.NumericUpDown numDrawing;
        private System.Windows.Forms.NumericUpDown numColour;
        private System.Windows.Forms.NumericUpDown numPapers;
        private System.Windows.Forms.NumericUpDown numFiles;
        private System.Windows.Forms.NumericUpDown numSharpeners;
        private System.Windows.Forms.NumericUpDown numErasers;
        private System.Windows.Forms.NumericUpDown numSlate;
        private System.Windows.Forms.NumericUpDown numPaint;
        private System.Windows.Forms.NumericUpDown numPencil;
        private System.Windows.Forms.NumericUpDown numNotebook;
        private System.Windows.Forms.NumericUpDown numPen;
        private System.Windows.Forms.NumericUpDown numCopybook;
        private System.Windows.Forms.CheckBox chkMechanical;
        private System.Windows.Forms.CheckBox chkColour;
        private System.Windows.Forms.CheckBox chkPapers;
        private System.Windows.Forms.CheckBox chkFiles;
        private System.Windows.Forms.CheckBox chkSharpener;
        private System.Windows.Forms.CheckBox chkEraser;
        private System.Windows.Forms.CheckBox chkRulers;
        private System.Windows.Forms.CheckBox chkSlate;
        private System.Windows.Forms.CheckBox chkPaint;
        private System.Windows.Forms.CheckBox chkDrawing;
        private System.Windows.Forms.CheckBox chkPencils;
        private System.Windows.Forms.CheckBox chkNotebooks;
        private System.Windows.Forms.CheckBox chkPen;
        private System.Windows.Forms.CheckBox chkCopybook;
        private System.Windows.Forms.TextBox txtItemPrice;
        private System.Windows.Forms.Label label1;
    }
}