﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1911606_PartB_
{
    public class clsEmployee
    {
        public static string EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpGender { get; set; }
        public int EmpNum { get; set; }
        public string position { get; set; }
    }
}
