﻿namespace _1911606_PartB_
{
    partial class BookPurchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkFearless = new System.Windows.Forms.CheckBox();
            this.chkTwilight = new System.Windows.Forms.CheckBox();
            this.chkNancy = new System.Windows.Forms.CheckBox();
            this.chkMortal = new System.Windows.Forms.CheckBox();
            this.chkHarry = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkTom = new System.Windows.Forms.CheckBox();
            this.chkAlchemist = new System.Windows.Forms.CheckBox();
            this.chkDarkWitch = new System.Windows.Forms.CheckBox();
            this.chkDavinci = new System.Windows.Forms.CheckBox();
            this.chkLastAct = new System.Windows.Forms.CheckBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtPrice
            // 
            this.txtPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.txtPrice.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.txtPrice.Location = new System.Drawing.Point(442, 471);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(174, 28);
            this.txtPrice.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(274, 475);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 19);
            this.label1.TabIndex = 24;
            this.label1.Text = "Total Book Price:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkFearless);
            this.groupBox2.Controls.Add(this.chkTwilight);
            this.groupBox2.Controls.Add(this.chkNancy);
            this.groupBox2.Controls.Add(this.chkMortal);
            this.groupBox2.Controls.Add(this.chkHarry);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Location = new System.Drawing.Point(472, 123);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(343, 292);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Series";
            // 
            // chkFearless
            // 
            this.chkFearless.AutoSize = true;
            this.chkFearless.Location = new System.Drawing.Point(21, 243);
            this.chkFearless.Name = "chkFearless";
            this.chkFearless.Size = new System.Drawing.Size(106, 26);
            this.chkFearless.TabIndex = 4;
            this.chkFearless.Text = "Fearless";
            this.chkFearless.UseVisualStyleBackColor = true;
            this.chkFearless.CheckedChanged += new System.EventHandler(this.chkFearless_CheckedChanged);
            // 
            // chkTwilight
            // 
            this.chkTwilight.AutoSize = true;
            this.chkTwilight.Location = new System.Drawing.Point(21, 191);
            this.chkTwilight.Name = "chkTwilight";
            this.chkTwilight.Size = new System.Drawing.Size(94, 26);
            this.chkTwilight.TabIndex = 3;
            this.chkTwilight.Text = "Twilight";
            this.chkTwilight.UseVisualStyleBackColor = true;
            this.chkTwilight.CheckedChanged += new System.EventHandler(this.chkTwilight_CheckedChanged);
            // 
            // chkNancy
            // 
            this.chkNancy.AutoSize = true;
            this.chkNancy.Location = new System.Drawing.Point(20, 140);
            this.chkNancy.Name = "chkNancy";
            this.chkNancy.Size = new System.Drawing.Size(133, 26);
            this.chkNancy.TabIndex = 2;
            this.chkNancy.Text = "Nancy Drew";
            this.chkNancy.UseVisualStyleBackColor = true;
            this.chkNancy.CheckedChanged += new System.EventHandler(this.chkNancy_CheckedChanged);
            // 
            // chkMortal
            // 
            this.chkMortal.AutoSize = true;
            this.chkMortal.Location = new System.Drawing.Point(20, 91);
            this.chkMortal.Name = "chkMortal";
            this.chkMortal.Size = new System.Drawing.Size(187, 26);
            this.chkMortal.TabIndex = 1;
            this.chkMortal.Text = "Mortal Instruments";
            this.chkMortal.UseVisualStyleBackColor = true;
            this.chkMortal.CheckedChanged += new System.EventHandler(this.chkMortal_CheckedChanged);
            // 
            // chkHarry
            // 
            this.chkHarry.AutoSize = true;
            this.chkHarry.Location = new System.Drawing.Point(20, 45);
            this.chkHarry.Name = "chkHarry";
            this.chkHarry.Size = new System.Drawing.Size(132, 26);
            this.chkHarry.TabIndex = 0;
            this.chkHarry.Text = "Harry Potter";
            this.chkHarry.UseVisualStyleBackColor = true;
            this.chkHarry.CheckedChanged += new System.EventHandler(this.chkHarry_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkTom);
            this.groupBox1.Controls.Add(this.chkAlchemist);
            this.groupBox1.Controls.Add(this.chkDarkWitch);
            this.groupBox1.Controls.Add(this.chkDavinci);
            this.groupBox1.Controls.Add(this.chkLastAct);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Location = new System.Drawing.Point(75, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(343, 292);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Books";
            // 
            // chkTom
            // 
            this.chkTom.AutoSize = true;
            this.chkTom.Location = new System.Drawing.Point(20, 243);
            this.chkTom.Name = "chkTom";
            this.chkTom.Size = new System.Drawing.Size(136, 26);
            this.chkTom.TabIndex = 4;
            this.chkTom.Text = "Tom Sawyer";
            this.chkTom.UseVisualStyleBackColor = true;
            this.chkTom.CheckedChanged += new System.EventHandler(this.chkTom_CheckedChanged);
            // 
            // chkAlchemist
            // 
            this.chkAlchemist.AutoSize = true;
            this.chkAlchemist.Location = new System.Drawing.Point(20, 191);
            this.chkAlchemist.Name = "chkAlchemist";
            this.chkAlchemist.Size = new System.Drawing.Size(152, 26);
            this.chkAlchemist.TabIndex = 3;
            this.chkAlchemist.Text = "The Alchemist";
            this.chkAlchemist.UseVisualStyleBackColor = true;
            this.chkAlchemist.CheckedChanged += new System.EventHandler(this.chkAlchemist_CheckedChanged);
            // 
            // chkDarkWitch
            // 
            this.chkDarkWitch.AutoSize = true;
            this.chkDarkWitch.Location = new System.Drawing.Point(20, 140);
            this.chkDarkWitch.Name = "chkDarkWitch";
            this.chkDarkWitch.Size = new System.Drawing.Size(124, 26);
            this.chkDarkWitch.TabIndex = 2;
            this.chkDarkWitch.Text = "Dark Witch";
            this.chkDarkWitch.UseVisualStyleBackColor = true;
            this.chkDarkWitch.CheckedChanged += new System.EventHandler(this.chkDarkWitch_CheckedChanged);
            // 
            // chkDavinci
            // 
            this.chkDavinci.AutoSize = true;
            this.chkDavinci.Location = new System.Drawing.Point(20, 91);
            this.chkDavinci.Name = "chkDavinci";
            this.chkDavinci.Size = new System.Drawing.Size(192, 26);
            this.chkDavinci.TabIndex = 1;
            this.chkDavinci.Text = "The Da Vinci Code";
            this.chkDavinci.UseVisualStyleBackColor = true;
            this.chkDavinci.CheckedChanged += new System.EventHandler(this.chkDavinci_CheckedChanged);
            // 
            // chkLastAct
            // 
            this.chkLastAct.AutoSize = true;
            this.chkLastAct.Location = new System.Drawing.Point(20, 45);
            this.chkLastAct.Name = "chkLastAct";
            this.chkLastAct.Size = new System.Drawing.Size(100, 26);
            this.chkLastAct.TabIndex = 0;
            this.chkLastAct.Text = "Last Act";
            this.chkLastAct.UseVisualStyleBackColor = true;
            this.chkLastAct.CheckedChanged += new System.EventHandler(this.chkLastAct_CheckedChanged);
            // 
            // BookPurchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(59)))), ((int)(((byte)(78)))));
            this.ClientSize = new System.Drawing.Size(891, 621);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "BookPurchase";
            this.Text = "BookPurchase";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkFearless;
        private System.Windows.Forms.CheckBox chkTwilight;
        private System.Windows.Forms.CheckBox chkNancy;
        private System.Windows.Forms.CheckBox chkMortal;
        private System.Windows.Forms.CheckBox chkHarry;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkTom;
        private System.Windows.Forms.CheckBox chkAlchemist;
        private System.Windows.Forms.CheckBox chkDarkWitch;
        private System.Windows.Forms.CheckBox chkDavinci;
        private System.Windows.Forms.CheckBox chkLastAct;
    }
}