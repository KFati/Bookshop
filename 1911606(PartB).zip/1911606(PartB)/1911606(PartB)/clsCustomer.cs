﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1911606_PartB_
{
    public class clsCustomer
    {
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Gender { get; set; }
        public int PhoneNum { get; set; }
    }
}
