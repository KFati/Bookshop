﻿namespace _1911606_PartB_
{
    partial class OfficeWorld
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnDelivery = new FontAwesome.Sharp.IconButton();
            this.BtnPayroll = new FontAwesome.Sharp.IconButton();
            this.BtnPayment = new FontAwesome.Sharp.IconButton();
            this.btnStaionaries = new FontAwesome.Sharp.IconButton();
            this.btnBooks = new FontAwesome.Sharp.IconButton();
            this.btnStationaryStore = new FontAwesome.Sharp.IconButton();
            this.BtnBookStore = new FontAwesome.Sharp.IconButton();
            this.BtnEmployee = new FontAwesome.Sharp.IconButton();
            this.btnCustomer = new FontAwesome.Sharp.IconButton();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.PictureBox();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.BtnMinimize = new System.Windows.Forms.PictureBox();
            this.BtnMaximize = new System.Windows.Forms.PictureBox();
            this.BtnClose = new System.Windows.Forms.PictureBox();
            this.lblTitleChildForm = new System.Windows.Forms.Label();
            this.iconCurrentChildForm = new FontAwesome.Sharp.IconPictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelShadow = new System.Windows.Forms.Panel();
            this.panelDesktop = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblClock = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).BeginInit();
            this.panelTitleBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMaximize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconCurrentChildForm)).BeginInit();
            this.panelDesktop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.panelMenu.Controls.Add(this.btnDelivery);
            this.panelMenu.Controls.Add(this.BtnPayroll);
            this.panelMenu.Controls.Add(this.BtnPayment);
            this.panelMenu.Controls.Add(this.btnStaionaries);
            this.panelMenu.Controls.Add(this.btnBooks);
            this.panelMenu.Controls.Add(this.btnStationaryStore);
            this.panelMenu.Controls.Add(this.BtnBookStore);
            this.panelMenu.Controls.Add(this.BtnEmployee);
            this.panelMenu.Controls.Add(this.btnCustomer);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(10, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(298, 752);
            this.panelMenu.TabIndex = 0;
            // 
            // btnDelivery
            // 
            this.btnDelivery.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDelivery.FlatAppearance.BorderSize = 0;
            this.btnDelivery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelivery.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnDelivery.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelivery.ForeColor = System.Drawing.Color.White;
            this.btnDelivery.IconChar = FontAwesome.Sharp.IconChar.ShoppingCart;
            this.btnDelivery.IconColor = System.Drawing.Color.Gainsboro;
            this.btnDelivery.IconSize = 32;
            this.btnDelivery.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelivery.Location = new System.Drawing.Point(0, 620);
            this.btnDelivery.Name = "btnDelivery";
            this.btnDelivery.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnDelivery.Rotation = 0D;
            this.btnDelivery.Size = new System.Drawing.Size(298, 60);
            this.btnDelivery.TabIndex = 10;
            this.btnDelivery.Text = "Delivery";
            this.btnDelivery.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelivery.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDelivery.UseVisualStyleBackColor = true;
            this.btnDelivery.Click += new System.EventHandler(this.btnDelivery_Click);
            // 
            // BtnPayroll
            // 
            this.BtnPayroll.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnPayroll.FlatAppearance.BorderSize = 0;
            this.BtnPayroll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPayroll.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnPayroll.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPayroll.ForeColor = System.Drawing.Color.Gainsboro;
            this.BtnPayroll.IconChar = FontAwesome.Sharp.IconChar.MoneyBillAlt;
            this.BtnPayroll.IconColor = System.Drawing.Color.Gainsboro;
            this.BtnPayroll.IconSize = 32;
            this.BtnPayroll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPayroll.Location = new System.Drawing.Point(0, 560);
            this.BtnPayroll.Name = "BtnPayroll";
            this.BtnPayroll.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.BtnPayroll.Rotation = 0D;
            this.BtnPayroll.Size = new System.Drawing.Size(298, 60);
            this.BtnPayroll.TabIndex = 9;
            this.BtnPayroll.Text = "Payroll";
            this.BtnPayroll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPayroll.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnPayroll.UseVisualStyleBackColor = true;
            this.BtnPayroll.Click += new System.EventHandler(this.BtnPayroll_Click);
            // 
            // BtnPayment
            // 
            this.BtnPayment.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnPayment.FlatAppearance.BorderSize = 0;
            this.BtnPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPayment.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnPayment.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPayment.ForeColor = System.Drawing.Color.Gainsboro;
            this.BtnPayment.IconChar = FontAwesome.Sharp.IconChar.CcApplePay;
            this.BtnPayment.IconColor = System.Drawing.Color.Gainsboro;
            this.BtnPayment.IconSize = 32;
            this.BtnPayment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPayment.Location = new System.Drawing.Point(0, 500);
            this.BtnPayment.Name = "BtnPayment";
            this.BtnPayment.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.BtnPayment.Rotation = 0D;
            this.BtnPayment.Size = new System.Drawing.Size(298, 60);
            this.BtnPayment.TabIndex = 8;
            this.BtnPayment.Text = "Payment";
            this.BtnPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPayment.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnPayment.UseVisualStyleBackColor = true;
            this.BtnPayment.Click += new System.EventHandler(this.BtnPayment_Click);
            // 
            // btnStaionaries
            // 
            this.btnStaionaries.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnStaionaries.FlatAppearance.BorderSize = 0;
            this.btnStaionaries.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStaionaries.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnStaionaries.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStaionaries.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnStaionaries.IconChar = FontAwesome.Sharp.IconChar.Pen;
            this.btnStaionaries.IconColor = System.Drawing.Color.Gainsboro;
            this.btnStaionaries.IconSize = 32;
            this.btnStaionaries.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStaionaries.Location = new System.Drawing.Point(0, 440);
            this.btnStaionaries.Name = "btnStaionaries";
            this.btnStaionaries.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnStaionaries.Rotation = 0D;
            this.btnStaionaries.Size = new System.Drawing.Size(298, 60);
            this.btnStaionaries.TabIndex = 7;
            this.btnStaionaries.Text = "Buy Stationaries";
            this.btnStaionaries.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStaionaries.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnStaionaries.UseVisualStyleBackColor = true;
            this.btnStaionaries.Click += new System.EventHandler(this.btnStaionaries_Click);
            // 
            // btnBooks
            // 
            this.btnBooks.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBooks.FlatAppearance.BorderSize = 0;
            this.btnBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBooks.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnBooks.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBooks.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnBooks.IconChar = FontAwesome.Sharp.IconChar.BookOpen;
            this.btnBooks.IconColor = System.Drawing.Color.Gainsboro;
            this.btnBooks.IconSize = 32;
            this.btnBooks.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBooks.Location = new System.Drawing.Point(0, 380);
            this.btnBooks.Name = "btnBooks";
            this.btnBooks.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnBooks.Rotation = 0D;
            this.btnBooks.Size = new System.Drawing.Size(298, 60);
            this.btnBooks.TabIndex = 6;
            this.btnBooks.Text = "Buy Books";
            this.btnBooks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBooks.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBooks.UseVisualStyleBackColor = true;
            this.btnBooks.Click += new System.EventHandler(this.btnBooks_Click);
            // 
            // btnStationaryStore
            // 
            this.btnStationaryStore.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnStationaryStore.FlatAppearance.BorderSize = 0;
            this.btnStationaryStore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStationaryStore.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnStationaryStore.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStationaryStore.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnStationaryStore.IconChar = FontAwesome.Sharp.IconChar.PencilAlt;
            this.btnStationaryStore.IconColor = System.Drawing.Color.Gainsboro;
            this.btnStationaryStore.IconSize = 32;
            this.btnStationaryStore.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStationaryStore.Location = new System.Drawing.Point(0, 320);
            this.btnStationaryStore.Name = "btnStationaryStore";
            this.btnStationaryStore.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnStationaryStore.Rotation = 0D;
            this.btnStationaryStore.Size = new System.Drawing.Size(298, 60);
            this.btnStationaryStore.TabIndex = 5;
            this.btnStationaryStore.Text = "Stationary ";
            this.btnStationaryStore.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStationaryStore.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnStationaryStore.UseVisualStyleBackColor = true;
            this.btnStationaryStore.Click += new System.EventHandler(this.btnStationaryStore_Click);
            // 
            // BtnBookStore
            // 
            this.BtnBookStore.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnBookStore.FlatAppearance.BorderSize = 0;
            this.BtnBookStore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBookStore.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnBookStore.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBookStore.ForeColor = System.Drawing.Color.Gainsboro;
            this.BtnBookStore.IconChar = FontAwesome.Sharp.IconChar.Book;
            this.BtnBookStore.IconColor = System.Drawing.Color.Gainsboro;
            this.BtnBookStore.IconSize = 32;
            this.BtnBookStore.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnBookStore.Location = new System.Drawing.Point(0, 260);
            this.BtnBookStore.Name = "BtnBookStore";
            this.BtnBookStore.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.BtnBookStore.Rotation = 0D;
            this.BtnBookStore.Size = new System.Drawing.Size(298, 60);
            this.BtnBookStore.TabIndex = 4;
            this.BtnBookStore.Text = "Book ";
            this.BtnBookStore.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnBookStore.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnBookStore.UseVisualStyleBackColor = true;
            this.BtnBookStore.Click += new System.EventHandler(this.BtnBookStore_Click);
            // 
            // BtnEmployee
            // 
            this.BtnEmployee.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnEmployee.FlatAppearance.BorderSize = 0;
            this.BtnEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEmployee.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.BtnEmployee.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEmployee.ForeColor = System.Drawing.Color.Gainsboro;
            this.BtnEmployee.IconChar = FontAwesome.Sharp.IconChar.UserFriends;
            this.BtnEmployee.IconColor = System.Drawing.Color.Gainsboro;
            this.BtnEmployee.IconSize = 32;
            this.BtnEmployee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEmployee.Location = new System.Drawing.Point(0, 200);
            this.BtnEmployee.Name = "BtnEmployee";
            this.BtnEmployee.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.BtnEmployee.Rotation = 0D;
            this.BtnEmployee.Size = new System.Drawing.Size(298, 60);
            this.BtnEmployee.TabIndex = 3;
            this.BtnEmployee.Text = "Employee";
            this.BtnEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEmployee.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnEmployee.UseVisualStyleBackColor = true;
            this.BtnEmployee.Click += new System.EventHandler(this.BtnEmployee_Click);
            // 
            // btnCustomer
            // 
            this.btnCustomer.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCustomer.FlatAppearance.BorderSize = 0;
            this.btnCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomer.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCustomer.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomer.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnCustomer.IconChar = FontAwesome.Sharp.IconChar.BookReader;
            this.btnCustomer.IconColor = System.Drawing.Color.Gainsboro;
            this.btnCustomer.IconSize = 32;
            this.btnCustomer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCustomer.Location = new System.Drawing.Point(0, 140);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnCustomer.Rotation = 0D;
            this.btnCustomer.Size = new System.Drawing.Size(298, 60);
            this.btnCustomer.TabIndex = 2;
            this.btnCustomer.Text = "Customer";
            this.btnCustomer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCustomer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCustomer.UseVisualStyleBackColor = true;
            this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.Controls.Add(this.btnHome);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(298, 140);
            this.panelLogo.TabIndex = 0;
            // 
            // btnHome
            // 
            this.btnHome.Image = global::_1911606_PartB_.Properties.Resources.f7667176_bc25_4f53_803a_aedcace32c7a_200x200;
            this.btnHome.Location = new System.Drawing.Point(3, 3);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(295, 137);
            this.btnHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnHome.TabIndex = 0;
            this.btnHome.TabStop = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.panelTitleBar.Controls.Add(this.BtnMinimize);
            this.panelTitleBar.Controls.Add(this.BtnMaximize);
            this.panelTitleBar.Controls.Add(this.BtnClose);
            this.panelTitleBar.Controls.Add(this.lblTitleChildForm);
            this.panelTitleBar.Controls.Add(this.iconCurrentChildForm);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.Location = new System.Drawing.Point(308, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(909, 75);
            this.panelTitleBar.TabIndex = 1;
            this.panelTitleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTitleBar_MouseDown);
            // 
            // BtnMinimize
            // 
            this.BtnMinimize.Image = global::_1911606_PartB_.Properties.Resources.icons8_minimize_window_35;
            this.BtnMinimize.Location = new System.Drawing.Point(776, 0);
            this.BtnMinimize.Name = "BtnMinimize";
            this.BtnMinimize.Size = new System.Drawing.Size(35, 35);
            this.BtnMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.BtnMinimize.TabIndex = 4;
            this.BtnMinimize.TabStop = false;
            this.BtnMinimize.Click += new System.EventHandler(this.BtnMinimize_Click);
            // 
            // BtnMaximize
            // 
            this.BtnMaximize.Image = global::_1911606_PartB_.Properties.Resources.icons8_maximize_window_35;
            this.BtnMaximize.Location = new System.Drawing.Point(817, 0);
            this.BtnMaximize.Name = "BtnMaximize";
            this.BtnMaximize.Size = new System.Drawing.Size(35, 35);
            this.BtnMaximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.BtnMaximize.TabIndex = 3;
            this.BtnMaximize.TabStop = false;
            this.BtnMaximize.Click += new System.EventHandler(this.BtnMaximize_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.Image = global::_1911606_PartB_.Properties.Resources.icons8_close_window_35;
            this.BtnClose.Location = new System.Drawing.Point(858, 0);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(35, 35);
            this.BtnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.BtnClose.TabIndex = 2;
            this.BtnClose.TabStop = false;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // lblTitleChildForm
            // 
            this.lblTitleChildForm.AutoSize = true;
            this.lblTitleChildForm.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleChildForm.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblTitleChildForm.Location = new System.Drawing.Point(69, 31);
            this.lblTitleChildForm.Name = "lblTitleChildForm";
            this.lblTitleChildForm.Size = new System.Drawing.Size(60, 21);
            this.lblTitleChildForm.TabIndex = 1;
            this.lblTitleChildForm.Text = "Home";
            // 
            // iconCurrentChildForm
            // 
            this.iconCurrentChildForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.iconCurrentChildForm.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.iconCurrentChildForm.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.iconCurrentChildForm.IconColor = System.Drawing.Color.LightSkyBlue;
            this.iconCurrentChildForm.IconSize = 39;
            this.iconCurrentChildForm.Location = new System.Drawing.Point(24, 22);
            this.iconCurrentChildForm.Name = "iconCurrentChildForm";
            this.iconCurrentChildForm.Size = new System.Drawing.Size(39, 40);
            this.iconCurrentChildForm.TabIndex = 0;
            this.iconCurrentChildForm.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.panel1.Location = new System.Drawing.Point(-3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(20, 1042);
            this.panel1.TabIndex = 2;
            // 
            // panelShadow
            // 
            this.panelShadow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.panelShadow.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelShadow.Location = new System.Drawing.Point(308, 75);
            this.panelShadow.Name = "panelShadow";
            this.panelShadow.Size = new System.Drawing.Size(909, 9);
            this.panelShadow.TabIndex = 3;
            // 
            // panelDesktop
            // 
            this.panelDesktop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(59)))), ((int)(((byte)(78)))));
            this.panelDesktop.Controls.Add(this.label1);
            this.panelDesktop.Controls.Add(this.pictureBox1);
            this.panelDesktop.Controls.Add(this.lblClock);
            this.panelDesktop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktop.Location = new System.Drawing.Point(308, 84);
            this.panelDesktop.Name = "panelDesktop";
            this.panelDesktop.Size = new System.Drawing.Size(909, 668);
            this.panelDesktop.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(286, 393);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 47);
            this.label1.TabIndex = 2;
            this.label1.Text = "Welcomes You!!";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::_1911606_PartB_.Properties.Resources.f7667176_bc25_4f53_803a_aedcace32c7a_200x200;
            this.pictureBox1.Location = new System.Drawing.Point(378, 170);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 186);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblClock
            // 
            this.lblClock.AutoSize = true;
            this.lblClock.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClock.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblClock.Location = new System.Drawing.Point(328, 460);
            this.lblClock.Name = "lblClock";
            this.lblClock.Size = new System.Drawing.Size(252, 47);
            this.lblClock.TabIndex = 0;
            this.lblClock.Text = "00:00:00 AM";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(54)))), ((int)(((byte)(72)))));
            this.panel2.Location = new System.Drawing.Point(1207, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(31, 1042);
            this.panel2.TabIndex = 3;
            // 
            // OfficeWorld
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1237, 752);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelDesktop);
            this.Controls.Add(this.panelShadow);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelTitleBar);
            this.Controls.Add(this.panelMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OfficeWorld";
            this.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).EndInit();
            this.panelTitleBar.ResumeLayout(false);
            this.panelTitleBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnMaximize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BtnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconCurrentChildForm)).EndInit();
            this.panelDesktop.ResumeLayout(false);
            this.panelDesktop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelLogo;
        private FontAwesome.Sharp.IconButton btnCustomer;
        private FontAwesome.Sharp.IconButton BtnPayroll;
        private FontAwesome.Sharp.IconButton BtnPayment;
        private FontAwesome.Sharp.IconButton btnStaionaries;
        private FontAwesome.Sharp.IconButton btnBooks;
        private FontAwesome.Sharp.IconButton btnStationaryStore;
        private FontAwesome.Sharp.IconButton BtnBookStore;
        private FontAwesome.Sharp.IconButton BtnEmployee;
        private System.Windows.Forms.PictureBox btnHome;
        private System.Windows.Forms.Panel panelTitleBar;
        private FontAwesome.Sharp.IconPictureBox iconCurrentChildForm;
        private System.Windows.Forms.Label lblTitleChildForm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelShadow;
        private System.Windows.Forms.Panel panelDesktop;
        private System.Windows.Forms.PictureBox BtnClose;
        private System.Windows.Forms.PictureBox BtnMaximize;
        private System.Windows.Forms.PictureBox BtnMinimize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblClock;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton btnDelivery;
    }
}

